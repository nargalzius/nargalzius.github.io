debug = false;
var images = ['f/i/common/bg.png'];

$(document).ready(function(){
	
	// INITALIZE EXPANDING UNIT
	expanding.init({
		//min_width   : 320,
		//min_height  : 50,
		//max_width   : 320,
		//max_height  : 480,
		//delay 	 	: .5,
		//rollover	: true,
		//mouseout	: true,
		//trigger		: $('#cta'),
		preload	 	: images,
		//fade		: false,
		exit        : "http://www.google.com",
		intro 		: customIntro,
		//expand      : customExpand,
		//collapse    : customCollapse,
		//direction   : "LEFT"
	});

});

function customIntro()
{
	TweenLite.from($('#cta'), 1.5, {
		delay: 1.5, 
		top: 250, 
		ease:Elastic.easeOut, 
		onComplete:expanding.ready
	});
}

function customExpand()
{

}

function customCollapse()
{

}