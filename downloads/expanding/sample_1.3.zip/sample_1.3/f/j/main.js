debug = false;
var images = ['http://nargalzius.github.io/img/joystick/background.png'];

$(document).ready(function(){
	
	// INITALIZE EXPANDING UNIT
	expanding.init({
		//minW   : 320,
		//minH  : 50,
		//maxW   : 320,
		//maxH  : 480,
		//delay 	 	: .5,
		//rollover	: true,
		//mouseout	: true,
		//trigger		: $('#cta'),
		preload	 	: images,
		//fade		: false,
		exit        : "http://www.google.com",
		intro 		: customIntro,
		//expand      : customExpand,
		//collapse    : customCollapse,
		//direction   : "UP"
	});

});

function customIntro()
{
	TweenLite.fromTo($('#collapsed .background'), 1.5, {
		backgroundColor: '#FFF'
	}, {
		delay: 1,
		backgroundColor: '#DDD'
	});

	TweenLite.from($('#cta'), 1.5, {
		delay: 1.5, 
		top: 250, 
		ease:Elastic.easeOut, 
		onComplete:expanding.ready
	});
}

function customExpand()
{

}

function customCollapse()
{

}