var images = ['f/i/col_bg.jpg'];

debug = true;

$(document).ready(function(){
	expanding.init({
		preload: images,
		//rollover: false,
		//hold: false,
		//trigger: $('#col_cta'),
		//exit: "http://google.com",
		intro: intro
	});
});

function intro()
{
	TweenLite.fromTo('#col_bg', 1.5, {
		autoAlpha: 0
	}, {
		delay: 1, 
		autoAlpha: 1
	});

	TweenLite.from('#col_cta', 1, {
		delay: 1.5,
		bottom: -50, 
		onComplete: expanding.ready,
		ease:Elastic.easeOut, 
	});
}