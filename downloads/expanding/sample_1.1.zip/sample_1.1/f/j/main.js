$(document).ready(function(){
	// INITALIZE EXPANDING UNIT
	expanding.init({
		min_width  		: 320,
		min_height 		: 50,
		max_width  		: 320,
		max_height 		: 480,
		delay 	 		: .5,
		direction		: "UP",
		rollover		: true,
		mouseout		: true,
		trigger			: $('#cta'),
		preload	 		: ['f/i/col_bg.jpg'],
		fade			: false,
		userExpand 		: function() {},
		userCollapse	: function() {},
		exit			: "http://www.google.com"
	});

});