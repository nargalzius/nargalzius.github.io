/* REQUIRES expandChild.js */

var images = [
	'f/i/col_bg.jpg',
	'f/i/col_btn.png'
];

$(document).ready(function(){
	expandChild.init({ preload: images } );
});