var images = ['f/i/col_bg.jpg','f/i/col_btn.png'];
debug = true;

$(document).ready(function(){
	console.log('jQuery');
	expanding.init({
		preload: images,
		rollover: false,
		hold: false,
		//delay: 1,
		trigger: $('#col_cta'),
		exit: "http://google.com",
		intro: intro
	});

});

function intro()
{
	TweenLite.from('#col_bg', 1.5, {autoAlpha:0});
	TweenLite.from('#col_cta', 2, {delay: 1.5, bottom: -50, ease:Elastic.easeOut});
}