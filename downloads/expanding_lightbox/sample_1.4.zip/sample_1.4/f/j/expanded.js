/* REQUIRES expandChild.js */

$(document).ready(function(){
	dom.init({
		//preload:['fail']
		preload:['http://nargalzius.github.io/img/joystick/background.png']
	});
});

