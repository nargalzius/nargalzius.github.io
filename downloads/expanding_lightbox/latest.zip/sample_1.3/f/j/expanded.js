/* REQUIRES expandChild.js */

$(document).ready(function(){
	expandChild.init();
});